var express = require('express');
var router = express.Router();

//try
const studentList = [
  {
    id: '1003',
    name: 'kelvin abaidoo',
    date_of_birth: '1990-04-14',
    programme: 'BSCCS',
    level: '100'
  },
  {
    id: '1004',
    name: 'jacqueline mensah',
    date_of_birth: '1990-04-14',
    programme: 'BSCCS',
    level: '200'
  },
  {
    id: '1203',
    name: 'james dawson',
    date_of_birth: '1990-04-14',
    programme: 'BSCCS',
    level: '300'
  }
];


/* GET students listing. */
router.get('/', function(req, res,) {
  res.render('students',{title: 'Students', studentList});
});




module.exports = router;
